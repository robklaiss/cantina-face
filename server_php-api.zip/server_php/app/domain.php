<?php

declare(strict_types=1);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/response.php';
require_once __DIR__ . '/auth/login.php';

function ensure_parent_student(int $parentId, int $studentId): void
{
    $exists = db_fetch(
        'SELECT 1 FROM parent_student WHERE parent_id = :pid AND student_id = :sid LIMIT 1',
        ['pid' => $parentId, 'sid' => $studentId]
    );
    if (!$exists) {
        json_error('El alumno no está vinculado a este tutor', 403);
    }
}

function list_student_orders(int $studentId, ?string $status = null): array
{
    $params = ['sid' => $studentId];
    $sql = 'SELECT * FROM scheduled_orders WHERE student_id = :sid';
    if ($status) {
        $sql .= ' AND status = :status';
        $params['status'] = $status;
    }
    $sql .= ' ORDER BY scheduled_for ASC';
    $orders = db_fetch_all($sql, $params);
    if (!$orders) {
        return [];
    }
    $orderIds = array_column($orders, 'id');
    $items = db_fetch_all(
        'SELECT * FROM scheduled_order_items WHERE order_id IN (' . implode(',', array_map('intval', $orderIds)) . ')'
    );
    $itemsByOrder = [];
    foreach ($items as $item) {
        $itemsByOrder[$item['order_id']][] = $item;
    }
    foreach ($orders as &$order) {
        $order['items'] = $itemsByOrder[$order['id']] ?? [];
    }
    return $orders;
}

function format_student_record(array $row): array
{
    $photo = $row['photo_path'] ?? null;
    return [
        'id' => (int) $row['id'],
        'name' => $row['name'],
        'grade' => $row['grade'] ?? '',
        'identifier' => $row['identifier'] ?? null,
        'balance' => isset($row['balance']) ? (float) $row['balance'] : 0.0,
        'photo_path' => $photo,
        'photo_url' => $photo ?: null,
        'created_at' => $row['created_at'] ?? null,
        'updated_at' => $row['updated_at'] ?? null,
    ];
}

function get_parent_students(int $parentId): array
{
    return db_fetch_all(
        'SELECT s.* FROM students s
         INNER JOIN parent_student ps ON ps.student_id = s.id
         WHERE ps.parent_id = :pid
         ORDER BY s.name ASC',
        ['pid' => $parentId]
    );
}

function get_parent_topups(int $parentId): array
{
    $rows = db_fetch_all(
        'SELECT * FROM topup_requests WHERE parent_id = :pid ORDER BY created_at DESC',
        ['pid' => $parentId]
    );
    return array_map('format_topup', $rows);
}

function format_topup(array $row): array
{
    return [
        'id' => (int) $row['id'],
        'parent_id' => (int) $row['parent_id'],
        'total_amount' => (float) $row['total_amount'],
        'allocation_mode' => $row['allocation_mode'],
        'allocations' => $row['allocations_json'] ? json_decode($row['allocations_json'], true) : null,
        'payment_reference' => $row['payment_reference'] ?? null,
        'status' => $row['status'],
        'admin_notes' => $row['admin_notes'] ?? null,
        'processed_at' => $row['processed_at'] ?? null,
        'created_at' => $row['created_at'],
        'updated_at' => $row['updated_at'],
    ];
}

function list_products(): array
{
    return db_fetch_all('SELECT * FROM products WHERE is_active = 1 ORDER BY name ASC');
}

function products_by_ids(array $ids): array
{
    if (!$ids) {
        return [];
    }
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = db()->prepare('SELECT * FROM products WHERE id IN (' . $placeholders . ')');
    $stmt->execute(array_values($ids));
    $rows = $stmt->fetchAll();
    $map = [];
    foreach ($rows as $row) {
        $map[$row['id']] = $row;
    }
    return $map;
}

function list_daily_menus(string $startDate): array
{
    $menus = db_fetch_all(
        'SELECT * FROM daily_menu WHERE menu_date >= :start ORDER BY menu_date ASC LIMIT 30',
        ['start' => $startDate]
    );
    $menuIds = array_column($menus, 'id');
    $items = [];
    if ($menuIds) {
        $items = db_fetch_all(
            'SELECT * FROM daily_menu_items WHERE menu_id IN (' . implode(',', array_map('intval', $menuIds)) . ') ORDER BY id ASC'
        );
    }
    $itemsByMenu = [];
    foreach ($items as $item) {
        $itemsByMenu[$item['menu_id']][] = $item;
    }
    foreach ($menus as &$menu) {
        $menu['items'] = $itemsByMenu[$menu['id']] ?? [];
    }
    return $menus;
}

function list_menu_selections(int $parentId): array
{
    return db_fetch_all(
        'SELECT * FROM menu_selections WHERE parent_id = :pid ORDER BY menu_date DESC',
        ['pid' => $parentId]
    );
}

function create_menu_selection(array $data): int
{
    return db_insert(
        'INSERT INTO menu_selections (menu_id, menu_item_id, student_id, parent_id, menu_date, notes)
         VALUES (:menu_id, :menu_item_id, :student_id, :parent_id, :menu_date, :notes)',
        $data
    );
}

function create_link_request(array $payload): int
{
    return db_insert(
        'INSERT INTO link_requests (parent_id, student_identifier, student_name, student_grade, notes)
         VALUES (:parent_id, :student_identifier, :student_name, :student_grade, :notes)',
        $payload
    );
}

function list_link_requests(?int $parentId = null): array
{
    return list_link_requests_filtered($parentId, null);
}

function list_link_requests_filtered(?int $parentId = null, ?string $status = null): array
{
    $where = [];
    $params = [];
    if ($parentId) {
        $where[] = 'parent_id = :pid';
        $params['pid'] = $parentId;
    }
    if ($status) {
        $where[] = 'status = :status';
        $params['status'] = $status;
    }
    $sql = 'SELECT * FROM link_requests';
    if ($where) {
        $sql .= ' WHERE ' . implode(' AND ', $where);
    }
    $sql .= ' ORDER BY created_at DESC';
    return db_fetch_all($sql, $params);
}

function update_link_request_status(int $requestId, string $status, ?int $studentId, ?string $adminNotes): void
{
    db_transaction(function () use ($requestId, $status, $studentId, $adminNotes) {
        $request = db_fetch('SELECT * FROM link_requests WHERE id = :id FOR UPDATE', ['id' => $requestId]);
        if (!$request) {
            json_error('Solicitud no encontrada', 404);
        }
        if ($request['status'] !== 'pending') {
            json_error('La solicitud ya fue procesada', 400);
        }

        if ($status === 'approved') {
            if (!$studentId) {
                json_error('student_id requerido para aprobar', 422);
            }
            db_insert(
                'INSERT IGNORE INTO parent_student (parent_id, student_id) VALUES (:pid, :sid)',
                ['pid' => $request['parent_id'], 'sid' => $studentId]
            );
        }

        db_execute(
            'UPDATE link_requests SET status = :status, admin_notes = :notes, processed_at = NOW()
             WHERE id = :id',
            ['status' => $status, 'notes' => $adminNotes, 'id' => $requestId]
        );
    });
}

function create_topup_request(array $data): int
{
    return db_insert(
        'INSERT INTO topup_requests (parent_id, total_amount, allocation_mode, allocations_json, payment_reference)
         VALUES (:parent_id, :total_amount, :allocation_mode, :allocations_json, :payment_reference)',
        $data
    );
}

function update_topup_status(int $id, string $status, ?string $paymentReference): void
{
    db_execute(
        'UPDATE topup_requests SET status = :status, payment_reference = :ref, processed_at = NOW() WHERE id = :id',
        ['status' => $status, 'ref' => $paymentReference, 'id' => $id]
    );
}

function list_scheduled_orders(int $parentId): array
{
    $orders = db_fetch_all(
        'SELECT * FROM scheduled_orders WHERE parent_id = :pid ORDER BY scheduled_for ASC',
        ['pid' => $parentId]
    );
    if (!$orders) {
        return [];
    }
    $orderIds = array_column($orders, 'id');
    $items = db_fetch_all(
        'SELECT * FROM scheduled_order_items WHERE order_id IN (' . implode(',', array_map('intval', $orderIds)) . ')'
    );
    $itemsByOrder = [];
    foreach ($items as $item) {
        $itemsByOrder[$item['order_id']][] = $item;
    }
    foreach ($orders as &$order) {
        $order['items'] = $itemsByOrder[$order['id']] ?? [];
    }
    return $orders;
}

function create_scheduled_order(array $order, array $items): int
{
    return db_transaction(function () use ($order, $items) {
        $orderId = db_insert(
            'INSERT INTO scheduled_orders (parent_id, student_id, scheduled_for, notes, pay_from_balance)
             VALUES (:parent_id, :student_id, :scheduled_for, :notes, :pay_from_balance)',
            $order
        );
        foreach ($items as $item) {
            db_insert(
                'INSERT INTO scheduled_order_items (order_id, product_id, quantity)
                 VALUES (:order_id, :product_id, :quantity)',
                ['order_id' => $orderId, 'product_id' => $item['product_id'], 'quantity' => $item['quantity']]
            );
        }
        return $orderId;
    });
}

function record_transaction(array $payload): int
{
    return db_insert(
        'INSERT INTO transactions (student_id, amount, txn_type, meta_json)
         VALUES (:student_id, :amount, :txn_type, :meta_json)',
        $payload
    );
}

function backend_stats(): array
{
    $totalUsers = db_fetch('SELECT COUNT(*) AS total FROM users') ?: ['total' => 0];
    $totalParents = db_fetch("SELECT COUNT(*) AS total FROM users WHERE role = 'parent'") ?: ['total' => 0];
    $students = db_fetch('SELECT COUNT(*) AS total FROM students') ?: ['total' => 0];
    $pendingTopups = db_fetch("SELECT COUNT(*) AS total FROM topup_requests WHERE status = 'pending'") ?: ['total' => 0];
    return [
        'users' => (int) $totalUsers['total'],
        'parents' => (int) $totalParents['total'],
        'students' => (int) $students['total'],
        'pending_topups' => (int) $pendingTopups['total'],
    ];
}

function list_all_topups(?string $status = null): array
{
    $sql = 'SELECT * FROM topup_requests';
    $params = [];
    if ($status) {
        $sql .= ' WHERE status = :status';
        $params['status'] = $status;
    }
    $sql .= ' ORDER BY created_at DESC';
    $rows = db_fetch_all($sql, $params);
    return array_map('format_topup', $rows);
}

function get_topup_by_id(int $id, bool $forUpdate = false): ?array
{
    $sql = 'SELECT * FROM topup_requests WHERE id = :id';
    if ($forUpdate) {
        $sql .= ' FOR UPDATE';
    }
    $row = db_fetch($sql, ['id' => $id]);
    return $row ? format_topup($row) : null;
}

function process_topup_decision(int $id, string $decision, ?string $paymentReference, ?string $adminNotes = null): array
{
    return db_transaction(function () use ($id, $decision, $paymentReference, $adminNotes) {
        $row = db_fetch('SELECT * FROM topup_requests WHERE id = :id FOR UPDATE', ['id' => $id]);
        if (!$row) {
            json_error('Top-up no encontrado', 404);
        }
        if ($row['status'] !== 'pending') {
            json_error('La solicitud ya fue procesada', 400);
        }

        $allocations = [];
        if ($decision === 'approved') {
            $allocations = $row['allocations_json'] ? json_decode($row['allocations_json'], true) : [];
            if (!is_array($allocations) || empty($allocations)) {
                json_error('No hay asignaciones para acreditar', 422);
            }
            foreach ($allocations as $studentId => $amount) {
                $studentId = (int) $studentId;
                $amount = (float) $amount;
                if ($amount <= 0) {
                    continue;
                }
                $updated = db_execute(
                    'UPDATE students SET balance = balance + :amount WHERE id = :sid',
                    ['amount' => $amount, 'sid' => $studentId]
                );
                if ($updated > 0) {
                    record_transaction([
                        'student_id' => $studentId,
                        'amount' => $amount,
                        'txn_type' => 'topup',
                        'meta_json' => json_encode(['topup_id' => $id]),
                    ]);
                }
            }
        }

        db_execute(
            'UPDATE topup_requests
             SET status = :status, payment_reference = :ref, admin_notes = :notes, processed_at = NOW()
             WHERE id = :id',
            [
                'status' => $decision,
                'ref' => $paymentReference,
                'notes' => $adminNotes,
                'id' => $id,
            ]
        );

        $updatedRow = db_fetch('SELECT * FROM topup_requests WHERE id = :id', ['id' => $id]);
        return format_topup($updatedRow);
    });
}

function list_students_admin(string $query = '', int $limit = 100): array
{
    $params = [];
    $sql = 'SELECT * FROM students';
    if ($query !== '') {
        $sql .= ' WHERE name LIKE :query OR grade LIKE :query';
        $params['query'] = '%' . $query . '%';
    }
    $sql .= ' ORDER BY name ASC LIMIT ' . max(1, (int) $limit);
    return db_fetch_all($sql, $params);
}

function find_student(int $studentId): ?array
{
    return db_fetch('SELECT * FROM students WHERE id = :id', ['id' => $studentId]);
}

function update_student(int $studentId, array $data): void
{
    $fields = [];
    $params = ['id' => $studentId];
    foreach (['name', 'grade', 'balance', 'photo_path'] as $column) {
        if (array_key_exists($column, $data)) {
            $fields[] = $column . ' = :' . $column;
            $params[$column] = $data[$column];
        }
    }
    if (!$fields) {
        return;
    }
    $sql = 'UPDATE students SET ' . implode(', ', $fields) . ', updated_at = NOW() WHERE id = :id';
    db_execute($sql, $params);
}

function delete_student(int $studentId): void
{
    db_execute('DELETE FROM students WHERE id = :id', ['id' => $studentId]);
}

function adjust_student_balance(int $studentId, float $amount, string $txnType = 'adjustment', array $meta = []): array
{
    db_transaction(function () use ($studentId, $amount, $txnType, $meta) {
        $updated = db_execute(
            'UPDATE students SET balance = balance + :amount WHERE id = :id',
            ['amount' => $amount, 'id' => $studentId]
        );
        if ($updated <= 0) {
            json_error('Alumno no encontrado', 404);
        }
        record_transaction([
            'student_id' => $studentId,
            'amount' => $amount,
            'txn_type' => $txnType,
            'meta_json' => json_encode($meta),
        ]);
    });

    $student = find_student($studentId);
    if (!$student) {
        json_error('Alumno no encontrado', 404);
    }
    return $student;
}

function list_transactions(int $limit = 100): array
{
    $sql = 'SELECT t.*, s.name AS student_name FROM transactions t
            LEFT JOIN students s ON s.id = t.student_id
            ORDER BY t.created_at DESC
            LIMIT ' . max(1, $limit);
    return db_fetch_all($sql);
}

function list_transactions_by_student(int $studentId, int $limit = 100): array
{
    $sql = 'SELECT * FROM transactions WHERE student_id = :sid ORDER BY created_at DESC LIMIT ' . max(1, $limit);
    return db_fetch_all($sql, ['sid' => $studentId]);
}

function search_transactions(?int $studentId, ?string $dateFrom, ?string $dateTo, ?string $txnType, int $limit = 200): array
{
    $where = [];
    $params = [];
    if ($studentId) {
        $where[] = 't.student_id = :sid';
        $params['sid'] = $studentId;
    }
    if ($dateFrom) {
        $where[] = 't.created_at >= :date_from';
        $params['date_from'] = $dateFrom;
    }
    if ($dateTo) {
        $where[] = 't.created_at <= :date_to';
        $params['date_to'] = $dateTo;
    }
    if ($txnType) {
        $where[] = 't.txn_type = :txn_type';
        $params['txn_type'] = $txnType;
    }
    $sql = 'SELECT t.*, s.name AS student_name FROM transactions t
            LEFT JOIN students s ON s.id = t.student_id';
    if ($where) {
        $sql .= ' WHERE ' . implode(' AND ', $where);
    }
    $sql .= ' ORDER BY t.created_at DESC LIMIT ' . max(1, $limit);
    return db_fetch_all($sql, $params);
}

function serialize_user_admin(array $user): array
{
    $data = serialize_user($user);
    $data['hashed_password'] = $user['password_hash'] ?? null;
    $data['plain_password'] = $user['plain_password'] ?? null;
    return $data;
}

function list_users_admin(): array
{
    $users = db_fetch_all('SELECT * FROM users ORDER BY created_at DESC');
    return array_map('serialize_user_admin', $users);
}

function find_user_admin(int $userId): ?array
{
    $user = find_user_by_id($userId);
    return $user ? serialize_user_admin($user) : null;
}

function create_user_admin(array $payload): array
{
    require_fields($payload, ['email', 'password', 'role']);
    $email = validate_email($payload['email']);
    if (find_user_by_email($email)) {
        json_error('El correo ya está registrado', 422);
    }

    $fullName = $payload['full_name'] ?? trim(($payload['first_name'] ?? '') . ' ' . ($payload['last_name'] ?? ''));
    $passwordHash = hash_password($payload['password']);

    $data = [
        'email' => $email,
        'full_name' => $fullName ?: $email,
        'first_name' => $payload['first_name'] ?? null,
        'last_name' => $payload['last_name'] ?? null,
        'dni' => $payload['dni'] ?? null,
        'phone' => $payload['phone'] ?? null,
        'role' => $payload['role'],
        'point_of_sale_id' => $payload['point_of_sale_id'] ?? null,
        'password_hash' => $passwordHash,
        'plain_password' => $payload['password'],
        'is_active' => isset($payload['is_active']) ? (int) $payload['is_active'] : 1,
    ];

    $columns = implode(', ', array_keys($data));
    $placeholders = ':' . implode(', :', array_keys($data));
    $id = db_insert("INSERT INTO users ({$columns}) VALUES ({$placeholders})", $data);
    $user = find_user_by_id($id);
    return serialize_user_admin($user);
}

function update_user_admin(int $userId, array $payload): array
{
    $user = find_user_by_id($userId);
    if (!$user) {
        json_error('Usuario no encontrado', 404);
    }

    $fields = [];
    $params = ['id' => $userId];
    $updatable = ['full_name', 'first_name', 'last_name', 'dni', 'phone', 'role', 'point_of_sale_id', 'is_active'];
    foreach ($updatable as $column) {
        if (array_key_exists($column, $payload)) {
            $fields[] = $column . ' = :' . $column;
            $params[$column] = $payload[$column];
        }
    }
    if (array_key_exists('plain_password', $payload) && $payload['plain_password']) {
        $fields[] = 'password_hash = :password_hash';
        $fields[] = 'plain_password = :plain_password';
        $params['plain_password'] = $payload['plain_password'];
        $params['password_hash'] = hash_password($payload['plain_password']);
    }
    if (!$fields) {
        return serialize_user_admin($user);
    }
    $sql = 'UPDATE users SET ' . implode(', ', $fields) . ', updated_at = NOW() WHERE id = :id';
    db_execute($sql, $params);
    $updated = find_user_by_id($userId);
    return serialize_user_admin($updated);
}

function reset_user_password_admin(int $userId, string $newPassword): array
{
    validate_password($newPassword);
    $hash = hash_password($newPassword);
    db_execute(
        'UPDATE users SET password_hash = :hash, plain_password = :plain WHERE id = :id',
        ['hash' => $hash, 'plain' => $newPassword, 'id' => $userId]
    );
    $user = find_user_by_id($userId);
    if (!$user) {
        json_error('Usuario no encontrado', 404);
    }
    return serialize_user_admin($user);
}


