<?php

declare(strict_types=1);

$root = dirname(__DIR__);
require_once $root . '/app/helpers.php';
require_once $root . '/app/logger.php';

$configPath = $root . '/config/config.php';
if (!is_file($configPath)) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode([
        'ok' => false,
        'error' => 'Config file missing. Please copy config/config.example.php to config.php and edit credentials.',
    ]);
    exit;
}

$config = require $configPath;
app_set('config', $config);

date_default_timezone_set($config['app']['timezone'] ?? 'UTC');

require_once $root . '/app/session.php';
require_once $root . '/app/response.php';
require_once $root . '/app/db.php';
require_once $root . '/app/validators.php';
require_once $root . '/app/auth/login.php';
require_once $root . '/app/auth/middleware.php';
require_once $root . '/app/domain.php';

set_error_handler(function ($severity, $message, $file, $line) {
    log_error('PHP error', compact('severity', 'message', 'file', 'line'));
    return false; // Let PHP handle according to error_reporting
});

set_exception_handler(function (Throwable $exception) {
    log_error('Uncaught exception', [
        'type' => get_class($exception),
        'message' => $exception->getMessage(),
        'file' => $exception->getFile(),
        'line' => $exception->getLine(),
    ]);
    json_error('Server error', 500);
});

register_shutdown_function(function () {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        log_error('Fatal error', $error);
    }
});

session_bootstrap();
