<?php

require_once __DIR__ . '/../app/bootstrap.php';

$action = strtolower((string) input('action', http_method() === 'GET' ? 'me' : 'login'));

switch ($action) {
    case 'login':
        handle_login();
        break;
    case 'logout':
        handle_logout();
        break;
    case 'me':
        handle_me();
        break;
    default:
        json_error('Acción no soportada', 404);
}

function require_method(string $method): void
{
    if (http_method() !== strtoupper($method)) {
        json_error('Método no permitido', 405);
    }
}

function handle_login(): void
{
    require_method('POST');
    rate_limit_check('login:' . get_client_ip(), 30, 60);

    $body = request_body();
    $email = $body['username'] ?? $body['email'] ?? input('username', input('email', ''));
    $password = $body['password'] ?? input('password');

    if (!$email || !$password) {
        json_error('Credenciales requeridas', 422);
    }

    $user = authenticate_credentials($email, $password);
    $session = issue_session_for_user($user);
    json_ok($session);
}

function handle_logout(): void
{
    require_method('POST');
    if (session_user()) {
        require_csrf_token();
        session_logout();
    }
    json_ok(['message' => 'Sesión finalizada']);
}

function handle_me(): void
{
    require_method('GET');
    $user = require_auth();
    json_ok([
        'user' => $user,
        'csrf_token' => $_SESSION['csrf_token'] ?? null,
    ]);
}

